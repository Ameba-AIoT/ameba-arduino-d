20210315204600PZEM-004T.HMI  is the project files
20210315204600PZEM-004T.tft  is the firmware