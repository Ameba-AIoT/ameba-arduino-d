This library provide examples of how to use L298N to control motors.
It also applied to 2WD cars which includes the way to adding thread,
thread signaling, register level gpio output, pwm control.