#ifndef _APP_FLAGS_H_
#define _APP_FLAGS_H_

#include "bt_flags.h"
#define APP_MAX_LINKS                       4

#endif
