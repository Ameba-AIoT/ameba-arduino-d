#ifndef _ATADRIVE_H_
#define _ATADRIVE_H_

#include "fatfs_ext/inc/ff_driver.h"

extern ll_diskio_drv ATA_disk_Driver;
#endif
