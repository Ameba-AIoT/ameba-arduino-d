#ifndef ATCMD_TLS_CERTS_H
#define ATCMD_TLS_CERTS_H

const unsigned char* clientCA = NULL;
const unsigned char* clientCert = NULL;
const unsigned char* clientKey = NULL;

const unsigned char* serverCA = NULL;
const unsigned char* serverCert = NULL;
const unsigned char* serverKey = NULL;

#endif
